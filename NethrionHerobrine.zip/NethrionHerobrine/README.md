# Nethrion Herobrine End Overhaul (Paper 1.21.11, Java 21)

Build:  mvn package   -> target/NethrionHerobrine-1.0.0.jar  -> put in plugins/
Test:   go to The End, run /herobrine start (perm: nethrion.herobrine.admin)
Commands: /herobrine start | stop | status | reload
Config: plugins/NethrionHerobrine/config.yml (health, damage, rewards, head texture)
