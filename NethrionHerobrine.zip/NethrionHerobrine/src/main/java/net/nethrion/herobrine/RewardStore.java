package net.nethrion.herobrine;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/** Durable reward bookkeeping: prevents duplicate rewards and holds rewards for offline players. */
public final class RewardStore {
    private final NethrionPlugin plugin;
    private final File file;
    private final YamlConfiguration yaml;

    public RewardStore(NethrionPlugin plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.yaml = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
    }

    /** @return true only the first time this player claims for this encounter. */
    public synchronized boolean tryClaim(UUID encounter, UUID player) {
        String path = "claimed." + encounter;
        List<String> list = new ArrayList<>(yaml.getStringList(path));
        if (list.contains(player.toString())) return false;
        list.add(player.toString());
        yaml.set(path, list);
        trim();
        save();
        return true;
    }

    public synchronized void addPending(UUID player) {
        List<String> list = new ArrayList<>(yaml.getStringList("pending"));
        if (!list.contains(player.toString())) list.add(player.toString());
        yaml.set("pending", list);
        save();
    }

    public synchronized boolean takePending(UUID player) {
        List<String> list = new ArrayList<>(yaml.getStringList("pending"));
        boolean removed = list.remove(player.toString());
        if (removed) {
            yaml.set("pending", list);
            save();
        }
        return removed;
    }

    private void trim() {
        ConfigurationSection s = yaml.getConfigurationSection("claimed");
        if (s == null) return;
        List<String> keys = new ArrayList<>(s.getKeys(false));
        while (keys.size() > 50) yaml.set("claimed." + keys.remove(0), null);
    }

    public synchronized void save() {
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save data.yml", e);
        }
    }
}
