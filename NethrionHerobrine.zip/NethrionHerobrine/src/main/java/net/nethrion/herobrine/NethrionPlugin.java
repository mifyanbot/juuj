package net.nethrion.herobrine;

import org.bukkit.plugin.java.JavaPlugin;

public final class NethrionPlugin extends JavaPlugin {
    private RewardStore rewards;
    private EncounterManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        rewards = new RewardStore(this);
        manager = new EncounterManager(this, rewards);
        manager.cleanupOrphans();
        getServer().getPluginManager().registerEvents(new EncounterListener(this, manager, rewards), this);
        HerobrineCommand cmd = new HerobrineCommand(this, manager);
        getCommand("herobrine").setExecutor(cmd);
        getCommand("herobrine").setTabCompleter(cmd);
        getLogger().info("Nethrion Herobrine End Overhaul enabled.");
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.shutdown();
        if (rewards != null) rewards.save();
    }
}
