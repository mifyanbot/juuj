package net.nethrion.herobrine;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.world.EntitiesLoadEvent;

public final class EncounterListener implements Listener {
    private final NethrionPlugin plugin;
    private final EncounterManager manager;
    private final RewardStore rewards;

    public EncounterListener(NethrionPlugin plugin, EncounterManager manager, RewardStore rewards) {
        this.plugin = plugin;
        this.manager = manager;
        this.rewards = rewards;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        manager.recordDamage(e.getEntity(), e.getDamager(), e.getFinalDamage());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent e) {
        if (manager.isBoss(e.getEntity())) {
            e.getDrops().clear();
            e.setDroppedExp(0);
            manager.onBossDeath(e.getEntity().getLocation());
        } else if (manager.isMinion(e.getEntity())) {
            e.getDrops().clear();
            e.setDroppedExp(0);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (rewards.takePending(p.getUniqueId())) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) manager.giveReward(p); }, 40L);
        }
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) manager.removeIfOrphan(en);
    }
}
