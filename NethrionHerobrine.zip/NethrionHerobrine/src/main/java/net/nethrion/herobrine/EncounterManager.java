package net.nethrion.herobrine;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.*;
import java.util.logging.Level;

/**
 * Owns the whole Herobrine encounter: one repeating task, one boss, bounded telegraphed attacks.
 * Lifecycle: IDLE -> INTRO -> PHASE_1 -> TRANSITION -> PHASE_2 -> TRANSITION -> PHASE_3 -> (victory) -> IDLE.
 */
public final class EncounterManager {
    public enum State { IDLE, INTRO, PHASE_1, PHASE_2, PHASE_3, TRANSITION }
    private enum Kind { LIGHTNING, SLAM, VOID, BLINK }
    private record Strike(Kind kind, Location loc, double radius, int startTick, int fireTick, double damage) {}

    private static final int STEP = 5;              // task period in ticks
    private static final int MAX_STRIKES = 24;      // hard cap on pending telegraphs
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final NethrionPlugin plugin;
    private final RewardStore rewards;
    private final NamespacedKey ownerKey;
    private final Random rnd = new Random();

    private State state = State.IDLE;
    private State afterTransition = State.PHASE_2;
    private UUID encounterId;
    private UUID bossId;
    private Location center;
    private double maxHealth;
    private BossBar bar;
    private BukkitTask task;
    private int tick, stateTicks, nextAttack, emptyTicks;

    private final Set<UUID> minions = new HashSet<>();
    private final Map<UUID, Double> damage = new HashMap<>();
    private final List<Strike> strikes = new ArrayList<>();
    private final Set<UUID> barViewers = new HashSet<>();

    public EncounterManager(NethrionPlugin plugin, RewardStore rewards) {
        this.plugin = plugin;
        this.rewards = rewards;
        this.ownerKey = new NamespacedKey(plugin, "herobrine_owned");
    }

    private FileConfiguration cfg() { return plugin.getConfig(); }

    // ------------------------------------------------------------------ public API

    /** @return null on success, otherwise an error message. */
    public String start(Player starter) {
        if (state != State.IDLE) return "An encounter is already running.";
        World w = starter.getWorld();
        if (w.getEnvironment() != World.Environment.THE_END) return "Herobrine can only be summoned in the End.";

        encounterId = UUID.randomUUID();
        maxHealth = cfg().getDouble("boss.health", 800);
        center = starter.getLocation().clone();
        tick = 0; stateTicks = 0; emptyTicks = 0;
        damage.clear(); strikes.clear(); minions.clear();

        Zombie z = spawnBoss(center);
        bossId = z.getUniqueId();
        bar = BossBar.bossBar(MM.deserialize("<white><bold>HEROBRINE"), 1f, BossBar.Color.WHITE, BossBar.Overlay.NOTCHED_10);
        state = State.INTRO;

        w.strikeLightningEffect(center);
        w.playSound(center, Sound.ENTITY_WITHER_SPAWN, 2f, 0.6f);
        title(participants(z), "<white><bold>HEROBRINE", "<gray>He has been watching...");
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::step, STEP, STEP);
        return null;
    }

    public void abort(String reason) {
        if (state == State.IDLE) return;
        Entity b = Bukkit.getEntity(bossId);
        if (b != null) {
            for (Player p : participants(b)) p.sendMessage(MM.deserialize("<gray>Herobrine fades away... (" + reason + ")"));
        }
        cleanup();
    }

    public void shutdown() { cleanup(); }

    public State getState() { return state; }

    public String status() {
        if (state == State.IDLE) return "No encounter running.";
        Entity b = Bukkit.getEntity(bossId);
        String hp = (b instanceof Zombie z) ? String.format("%.0f/%.0f", z.getHealth(), maxHealth) : "?";
        return "State: " + state + " | HP: " + hp + " | Minions: " + minions.size() + " | Pending strikes: " + strikes.size();
    }

    public boolean isBoss(Entity e) { return bossId != null && e.getUniqueId().equals(bossId); }
    public boolean isMinion(Entity e) { return minions.contains(e.getUniqueId()); }

    public void recordDamage(Entity victim, Entity damager, double amount) {
        if (state == State.IDLE || !isBoss(victim)) return;
        Player p = null;
        if (damager instanceof Player pl) p = pl;
        else if (damager instanceof Projectile pr && pr.getShooter() instanceof Player pl2) p = pl2;
        if (p != null) damage.merge(p.getUniqueId(), amount, Double::sum);
    }

    /** Called from the death event of the boss. Rewards each qualified contributor exactly once. */
    public void onBossDeath(Location where) {
        if (state == State.IDLE) return;
        UUID enc = encounterId;
        double minDmg = cfg().getDouble("reward.min-damage", 40);
        for (Map.Entry<UUID, Double> e : new HashMap<>(damage).entrySet()) {
            if (e.getValue() < minDmg) continue;
            if (!rewards.tryClaim(enc, e.getKey())) continue;   // duplicate protection
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null) giveReward(p); else rewards.addPending(e.getKey());
        }
        World w = where.getWorld();
        w.strikeLightningEffect(where);
        w.playSound(where, Sound.UI_TOAST_CHALLENGE_COMPLETE, 2f, 1f);
        w.spawnParticle(Particle.END_ROD, where.clone().add(0, 1, 0), 120, 1.5, 2, 1.5, 0.1);
        title(w.getPlayers().stream().filter(p -> p.getLocation().distanceSquared(where) < 80 * 80).toList(),
                "<gold><bold>HEROBRINE DEFEATED", "<gray>The End is quiet again.");
        cleanup();
    }

    public void giveReward(Player p) {
        ItemStack sword = new ItemStack(Material.NETHERITE_SWORD);
        sword.editMeta(m -> {
            m.displayName(MM.deserialize("<!italic><gold><bold>Herobrine's Bane"));
            m.lore(List.of(MM.deserialize("<!italic><gray>Forged from the End's forgotten shadow.")));
            m.addEnchant(Enchantment.SHARPNESS, 6, true);
            m.addEnchant(Enchantment.FIRE_ASPECT, 2, true);
            m.getPersistentDataContainer().set(new NamespacedKey(plugin, "herobrine_bane"), PersistentDataType.BYTE, (byte) 1);
        });
        ItemStack sigil = new ItemStack(Material.NETHER_STAR);
        sigil.editMeta(m -> {
            m.displayName(MM.deserialize("<!italic><white><bold>Herobrine's Sigil"));
            m.lore(List.of(MM.deserialize("<!italic><gray>Proof that you faced him.")));
            m.getPersistentDataContainer().set(new NamespacedKey(plugin, "herobrine_sigil"), PersistentDataType.BYTE, (byte) 1);
        });
        Map<Integer, ItemStack> left = p.getInventory().addItem(sword, sigil);
        left.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
        p.giveExp(cfg().getInt("reward.xp", 2000));
        p.sendMessage(MM.deserialize("<gold>You received <bold>Herobrine's Bane</bold> and a Sigil!"));
    }

    // ------------------------------------------------------------------ orphan recovery

    public void cleanupOrphans() {
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities()) removeIfOrphan(e);
    }

    public void removeIfOrphan(Entity e) {
        String tag = e.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (tag == null) return;
        if (state == State.IDLE || encounterId == null || !encounterId.toString().equals(tag)) e.remove();
    }

    // ------------------------------------------------------------------ main loop

    private void step() {
        try {
            doStep();
        } catch (Exception ex) {
            plugin.getLogger().log(Level.SEVERE, "Herobrine encounter crashed, aborting safely", ex);
            abort("internal error");
        }
    }

    private void doStep() {
        if (state == State.IDLE) return;
        tick += STEP;
        stateTicks += STEP;

        Entity e = Bukkit.getEntity(bossId);
        if (!(e instanceof Zombie z) || !z.isValid()) { abort("Herobrine vanished"); return; }
        if (z.getLocation().getY() < center.getY() - 40) z.teleport(center);   // fell into the void

        List<Player> ps = participants(z);
        updateBar(z, ps);
        if (ps.isEmpty()) {
            emptyTicks += STEP;
            if (emptyTicks >= 1200) { abort("no challengers"); return; }
        } else emptyTicks = 0;

        processStrikes(z);

        if (state == State.INTRO) {
            z.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, z.getLocation().add(0, 1, 0), 10, 0.5, 1, 0.5, 0.02);
            if (stateTicks >= 100) { unfreeze(z); state = State.PHASE_1; nextAttack = tick + 60; }
            return;
        }
        if (state == State.TRANSITION) {
            z.getWorld().spawnParticle(Particle.REVERSE_PORTAL, z.getLocation().add(0, 1, 0), 30, 0.6, 1.2, 0.6, 0.1);
            if (stateTicks >= 60) { unfreeze(z); state = afterTransition; nextAttack = tick + 40; }
            return;
        }

        double frac = z.getHealth() / maxHealth;
        if (state == State.PHASE_1 && frac <= 0.66) { beginTransition(z, State.PHASE_2, ps); return; }
        if (state == State.PHASE_2 && frac <= 0.33) { beginTransition(z, State.PHASE_3, ps); return; }

        if (tick >= nextAttack && !ps.isEmpty()) {
            doAttack(z, ps);
            nextAttack = tick + switch (state) { case PHASE_1 -> 100; case PHASE_2 -> 80; default -> 60; };
        }
    }

    private void unfreeze(Zombie z) { z.setInvulnerable(false); z.setAI(true); }

    private void beginTransition(Zombie z, State next, List<Player> ps) {
        state = State.TRANSITION;
        afterTransition = next;
        stateTicks = 0;
        z.setInvulnerable(true);
        z.setAI(false);
        strikes.clear();
        removeMinions();
        z.getWorld().playSound(z.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 2f, 0.7f);
        title(ps, next == State.PHASE_2 ? "<red><bold>PHASE II" : "<dark_red><bold>PHASE III",
                next == State.PHASE_2 ? "<gray>He is done holding back." : "<gray>The End begins to break.");
    }

    // ------------------------------------------------------------------ attacks (all telegraphed)

    private void doAttack(Zombie z, List<Player> ps) {
        Player t = ps.get(rnd.nextInt(ps.size()));
        int roll = rnd.nextInt(100);
        switch (state) {
            case PHASE_1 -> { if (roll < 55) lightning(t); else slam(z, ps); }
            case PHASE_2 -> {
                if (roll < 30) lightning(t);
                else if (roll < 55) slam(z, ps);
                else if (roll < 80) shades(z);
                else blink(z, t);
            }
            case PHASE_3 -> {
                if (roll < 30) voidRain(ps);
                else if (roll < 50) slam(z, ps);
                else if (roll < 70) blink(z, t);
                else if (roll < 85) shades(z);
                else lightning(t);
            }
            default -> { }
        }
    }

    private void addStrike(Kind k, Location loc, double r, int delay, double dmg) {
        if (strikes.size() >= MAX_STRIKES) return;
        strikes.add(new Strike(k, loc.clone(), r, tick, tick + delay, dmg));
    }

    private void lightning(Player t) {
        addStrike(Kind.LIGHTNING, t.getLocation(), 3.0, 40, cfg().getDouble("damage.lightning", 8));
        t.sendActionBar(MM.deserialize("<yellow>Lightning is marked on you - MOVE!"));
        t.playSound(t.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.6f);
    }

    private void slam(Zombie z, List<Player> ps) {
        addStrike(Kind.SLAM, z.getLocation(), 7.0, 30, cfg().getDouble("damage.slam", 10));
        z.getWorld().playSound(z.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 2f, 0.6f);
        for (Player p : ps) p.sendActionBar(MM.deserialize("<red><bold>SHADOW SLAM - JUMP when the ring closes!"));
    }

    private void voidRain(List<Player> ps) {
        for (int i = 0; i < 6; i++) {
            Player t = ps.get(rnd.nextInt(ps.size()));
            Location l = t.getLocation().clone().add(rnd.nextDouble() * 8 - 4, 0, rnd.nextDouble() * 8 - 4);
            addStrike(Kind.VOID, l, 2.5, 40 + i * 5, cfg().getDouble("damage.void", 6));
        }
        for (Player p : ps) p.sendActionBar(MM.deserialize("<light_purple>Void rain! Watch the purple rings."));
    }

    private void blink(Zombie z, Player t) {
        Location dest = t.getLocation().clone().add(t.getLocation().getDirection().setY(0).normalize().multiply(-2.5));
        addStrike(Kind.BLINK, dest, 2.5, 30, cfg().getDouble("damage.blink", 5));
        t.sendActionBar(MM.deserialize("<white>He is about to appear behind you..."));
    }

    private void shades(Zombie z) {
        minions.removeIf(id -> { Entity m = Bukkit.getEntity(id); return m == null || !m.isValid(); });
        int n = Math.min(2, cfg().getInt("minions.cap", 4) - minions.size());
        for (int i = 0; i < n; i++) {
            Location l = z.getLocation().clone().add(rnd.nextDouble() * 4 - 2, 1, rnd.nextDouble() * 4 - 2);
            Vex v = z.getWorld().spawn(l, Vex.class, x -> {
                x.customName(MM.deserialize("<dark_gray>Shade"));
                x.setPersistent(false);
                x.setRemoveWhenFarAway(true);
                x.setLimitedLifetime(true);
                x.setLimitedLifetimeTicks(400);   // self-destructs after 20s
                setAttr(x, Attribute.MAX_HEALTH, 14);
                x.setHealth(14);
                x.getEquipment().setItemInMainHand(new ItemStack(Material.IRON_SWORD));
                x.getEquipment().setItemInMainHandDropChance(0f);
                x.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, encounterId.toString());
            });
            minions.add(v.getUniqueId());
        }
        z.getWorld().playSound(z.getLocation(), Sound.ENTITY_EVOKER_PREPARE_SUMMON, 2f, 0.6f);
    }

    private void processStrikes(Zombie z) {
        Iterator<Strike> it = strikes.iterator();
        while (it.hasNext()) {
            Strike s = it.next();
            if (tick >= s.fireTick()) { it.remove(); resolve(z, s); }
            else drawTelegraph(s);
        }
    }

    private void drawTelegraph(Strike s) {
        World w = s.loc().getWorld();
        double total = Math.max(1, s.fireTick() - s.startTick());
        double prog = Math.min(1, (tick - s.startTick()) / total);
        Particle.DustOptions dust = new Particle.DustOptions(colorFor(s.kind()), 1.5f);
        ring(w, s.loc(), s.radius(), dust);
        ring(w, s.loc(), Math.max(0.3, s.radius() * prog), dust);
    }

    private void ring(World w, Location c, double r, Particle.DustOptions dust) {
        for (int i = 0; i < 16; i++) {
            double a = i * (Math.PI * 2 / 16);
            w.spawnParticle(Particle.DUST, c.getX() + Math.cos(a) * r, c.getY() + 0.15, c.getZ() + Math.sin(a) * r, 1, 0, 0, 0, 0, dust);
        }
    }

    private Color colorFor(Kind k) {
        return switch (k) {
            case LIGHTNING -> Color.ORANGE;
            case SLAM -> Color.RED;
            case VOID -> Color.PURPLE;
            case BLINK -> Color.WHITE;
        };
    }

    private void resolve(Zombie z, Strike s) {
        World w = s.loc().getWorld();
        switch (s.kind()) {
            case LIGHTNING -> {
                w.strikeLightningEffect(s.loc());
                w.spawnParticle(Particle.EXPLOSION_EMITTER, s.loc(), 1);
                hit(z, s.loc(), s.radius(), s.damage(), false, false);
            }
            case VOID -> {
                w.playSound(s.loc(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.5f);
                w.spawnParticle(Particle.REVERSE_PORTAL, s.loc().clone().add(0, 1, 0), 60, 1, 1.5, 1, 0.2);
                hit(z, s.loc(), s.radius(), s.damage(), false, false);
            }
            case SLAM -> {
                w.playSound(s.loc(), Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.7f);
                w.spawnParticle(Particle.EXPLOSION_EMITTER, s.loc(), 2, 1.5, 0.2, 1.5, 0);
                hit(z, s.loc(), s.radius(), s.damage(), true, true);   // airborne players dodge it
            }
            case BLINK -> {
                w.spawnParticle(Particle.PORTAL, z.getLocation().add(0, 1, 0), 60, 0.5, 1, 0.5, 0.5);
                z.teleport(s.loc());
                w.playSound(s.loc(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.8f);
                hit(z, s.loc(), s.radius(), s.damage(), false, true);
            }
        }
    }

    private void hit(Zombie z, Location loc, double radius, double dmg, boolean needGround, boolean knock) {
        for (Player p : loc.getWorld().getNearbyPlayers(loc, radius, 4, radius)) {
            GameMode gm = p.getGameMode();
            if (p.isDead() || (gm != GameMode.SURVIVAL && gm != GameMode.ADVENTURE)) continue;
            double dx = p.getLocation().getX() - loc.getX(), dz = p.getLocation().getZ() - loc.getZ();
            if (dx * dx + dz * dz > radius * radius) continue;
            if (needGround && !p.isOnGround()) { p.sendActionBar(MM.deserialize("<green>Dodged!")); continue; }
            p.damage(dmg, z);
            if (knock) {
                Vector v = p.getLocation().toVector().subtract(loc.toVector()).setY(0);
                if (v.lengthSquared() > 0.0001) v.normalize().multiply(0.9);
                p.setVelocity(v.setY(0.5));
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private Zombie spawnBoss(Location loc) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        String tex = cfg().getString("boss.head-texture", "");
        head.editMeta(SkullMeta.class, m -> {
            com.destroystokyo.paper.profile.PlayerProfile prof = Bukkit.createProfile(UUID.randomUUID(), "Herobrine");
            if (!tex.isBlank()) prof.setProperty(new com.destroystokyo.paper.profile.ProfileProperty("textures", tex));
            m.setPlayerProfile(prof);
        });
        return loc.getWorld().spawn(loc, Zombie.class, z -> {
            z.customName(MM.deserialize("<white><bold>Herobrine"));
            z.setCustomNameVisible(false);
            z.setBaby(false);
            z.setShouldBurnInDay(false);
            z.setRemoveWhenFarAway(false);
            z.setPersistent(false);              // never saved to disk -> no orphan after restart
            z.setCanPickupItems(false);
            z.setAI(false);                      // frozen during intro
            z.setInvulnerable(true);
            setAttr(z, Attribute.MAX_HEALTH, maxHealth);
            setAttr(z, Attribute.ATTACK_DAMAGE, cfg().getDouble("boss.melee-damage", 10));
            setAttr(z, Attribute.MOVEMENT_SPEED, 0.28);
            setAttr(z, Attribute.KNOCKBACK_RESISTANCE, 0.9);
            setAttr(z, Attribute.FOLLOW_RANGE, 64);
            setAttr(z, Attribute.SPAWN_REINFORCEMENTS, 0);
            setAttr(z, Attribute.SCALE, cfg().getDouble("boss.scale", 1.4));
            z.setHealth(maxHealth);
            EntityEquipment eq = z.getEquipment();
            eq.setHelmet(head);
            eq.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
            eq.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
            eq.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
            eq.setItemInMainHand(new ItemStack(Material.DIAMOND_SWORD));
            eq.setHelmetDropChance(0f); eq.setChestplateDropChance(0f);
            eq.setLeggingsDropChance(0f); eq.setBootsDropChance(0f);
            eq.setItemInMainHandDropChance(0f);
            z.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, encounterId.toString());
        });
    }

    private static void setAttr(LivingEntity e, Attribute a, double v) {
        AttributeInstance inst = e.getAttribute(a);
        if (inst != null) inst.setBaseValue(v);
    }

    private List<Player> participants(Entity boss) {
        List<Player> list = new ArrayList<>();
        double r = cfg().getDouble("arena.radius", 64);
        for (Player p : boss.getWorld().getPlayers()) {
            GameMode gm = p.getGameMode();
            if (p.isDead() || (gm != GameMode.SURVIVAL && gm != GameMode.ADVENTURE)) continue;
            if (p.getLocation().distanceSquared(boss.getLocation()) <= r * r) list.add(p);
        }
        return list;
    }

    private void updateBar(Zombie z, List<Player> ps) {
        bar.progress((float) Math.max(0, Math.min(1, z.getHealth() / maxHealth)));
        bar.name(MM.deserialize("<white><bold>HEROBRINE</bold> <gray>- " + switch (state) {
            case INTRO -> "Awakening";
            case PHASE_1 -> "Phase I";
            case PHASE_2 -> "Phase II";
            case PHASE_3 -> "Phase III";
            case TRANSITION -> "Changing...";
            default -> "";
        }));
        Set<UUID> now = new HashSet<>();
        for (Player p : ps) {
            now.add(p.getUniqueId());
            if (barViewers.add(p.getUniqueId())) p.showBossBar(bar);
        }
        Iterator<UUID> it = barViewers.iterator();
        while (it.hasNext()) {
            UUID id = it.next();
            if (!now.contains(id)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) p.hideBossBar(bar);
                it.remove();
            }
        }
    }

    private void title(Collection<? extends Player> ps, String main, String sub) {
        Title t = Title.title(MM.deserialize(main), MM.deserialize(sub),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(800)));
        for (Player p : ps) p.showTitle(t);
    }

    private void removeMinions() {
        for (UUID id : minions) { Entity m = Bukkit.getEntity(id); if (m != null) m.remove(); }
        minions.clear();
    }

    /** Single exit path: everything the encounter created is removed here. */
    private void cleanup() {
        if (task != null) { task.cancel(); task = null; }
        if (bossId != null) { Entity b = Bukkit.getEntity(bossId); if (b != null) b.remove(); }
        removeMinions();
        strikes.clear();
        if (bar != null) {
            for (UUID id : barViewers) { Player p = Bukkit.getPlayer(id); if (p != null) p.hideBossBar(bar); }
            barViewers.clear();
            bar = null;
        }
        damage.clear();
        bossId = null; encounterId = null; center = null;
        state = State.IDLE;
    }
}
