package net.nethrion.herobrine;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

public final class HerobrineCommand implements TabExecutor {
    private final NethrionPlugin plugin;
    private final EncounterManager manager;

    public HerobrineCommand(NethrionPlugin plugin, EncounterManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) { s.sendMessage("/herobrine <start|stop|status|reload>"); return true; }
        switch (a[0].toLowerCase()) {
            case "start" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
                String err = manager.start(p);
                s.sendMessage(err == null ? "Herobrine awakens..." : err);
            }
            case "stop" -> { manager.abort("stopped by admin"); s.sendMessage("Encounter stopped."); }
            case "status" -> s.sendMessage(manager.status());
            case "reload" -> { plugin.reloadConfig(); s.sendMessage("Config reloaded."); }
            default -> s.sendMessage("/herobrine <start|stop|status|reload>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        return a.length == 1 ? List.of("start", "stop", "status", "reload") : List.of();
    }
}
